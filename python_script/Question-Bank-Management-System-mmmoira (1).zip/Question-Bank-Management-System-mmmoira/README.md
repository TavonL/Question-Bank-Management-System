﻿# 2019/5/22 moira
##命令##

`cd backend`  
`set FLASK_APP=flaskr`  
`set FLASK_ENV=development`  
`flask run`  